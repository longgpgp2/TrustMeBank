package com.trustme.dto.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TransferMapper {

}
