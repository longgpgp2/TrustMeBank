package com.trustme.config.filter;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;

public class BearerTokenAuthenticationFilterImpl extends BearerTokenAuthenticationFilter {
    public BearerTokenAuthenticationFilterImpl(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    public BearerTokenAuthenticationFilterImpl(AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver) {
        super(authenticationManagerResolver);
    }
}
