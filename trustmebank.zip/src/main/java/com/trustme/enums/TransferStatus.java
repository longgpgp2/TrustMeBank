package com.trustme.enums;

public enum TransferStatus {
    STARTED, PENDING, COMPLETED
}
