package com.trustme.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;

@RestController
@RequestMapping("/auth/multi-step")
public class MultiStepTransactionController {

    @PostMapping("/step-one")
    public ResponseEntity<Void> stepOne() {
        URI nextStep = URI.create("/auth/multi-step/step-two");
        return ResponseEntity.status(HttpStatus.FOUND).location(nextStep).build();
    }
    @GetMapping("/step-two")
    public ResponseEntity<String> stepTwoGet() {
        return ResponseEntity.status(HttpStatus.FOUND).body("In step two");
    }

    @PostMapping("/step-two")
    public ResponseEntity<String> stepTwo() {
        return ResponseEntity.ok("Step two completed");
    }
}
