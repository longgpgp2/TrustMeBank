package com.trustme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrustMeBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrustMeBankApplication.class, args);
	}

}
