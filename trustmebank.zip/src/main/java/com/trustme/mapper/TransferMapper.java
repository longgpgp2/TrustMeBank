package com.trustme.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TransferMapper {

}
